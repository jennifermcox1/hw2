from django.http import HttpResponse
from django.shortcuts import render
import operator
from random import random, randint


def home(request):
    return render(request, 'home.html')

def playgame(request):

    dice1 = randint(1,6)
    dice2 = randint(1,6)
    total = dice1 + dice2
    result = ''

    if total in [2,3,12]:
        result= "You Win"
    elif total in [7,11]:
        result= "You Lose"
    else:
        result = "Push"


    return render(request, 'playgame.html', {'dice1':dice1, 'dice2':dice2, 
    'total':total, 'result':result})